# Perguntas frequentes da imersão

## Preciso deixar meu computador ligado?
Não. O agente roda na VPS. Você fala com ele pelo Telegram.

## Posso usar no celular?
Sim. Pelo Telegram.

## Ele vai entrar no meu Instagram sozinho?
Não. Você faz login manualmente no navegador. Depois ele pode operar apenas com sua autorização.

## Posso mandar minha senha para ele?
Não. Senha, token, código 2FA e dados sensíveis nunca devem ser enviados no chat.

## Ele pode postar por mim?
Pode, se a ferramenta estiver conectada e você autorizar antes. No começo, sempre revise.

## Ele pode prospectar sozinho?
Ele pode pesquisar, qualificar e preparar mensagens. Envio automático precisa de muita cautela e autorização, porque redes sociais e WhatsApp têm limites e podem restringir conta.

## Ele edita vídeo igual ferramenta profissional?
Ele pode ajudar com roteiro, corte, legenda, título e usar ferramentas disponíveis. Edição pesada depende das ferramentas/APIs instaladas. VPS comum não é GPU.

## Preciso pagar API?
Depende do modelo usado. O portal/configuração do Hermes pode resolver parte disso. OpenRouter/OpenAI/DeepSeek exigem chave e saldo próprios.

## O que fazer se parar de responder?
Verifique:

```bash
hermes gateway status
tail -f ~/.hermes/logs/gateway.log
```

## O bot não responde no Telegram
Possíveis causas:
- gateway parado;
- token errado;
- user ID não autorizado;
- você não mandou `/start` no bot;
- modelo/API sem saldo.

## Dá para ter mais de uma pessoa no mesmo bot?
Dá, mas para a imersão é melhor um bot por aluno para não misturar contexto.
