# Instalação VPS + Telegram + Composio + navegador

## 1. Requisitos

Para cada aluno:
- 1 VPS Ubuntu limpa.
- Acesso SSH ou painel da VPS.
- Telegram do aluno.
- E-mail do aluno.
- Conta nas ferramentas que ele quiser conectar.
- Instagram próprio se for usar social selling.

## 2. Instalar Hermes

Na VPS Linux:

```bash
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
```

Depois:

```bash
hermes setup --portal
```

O caminho mais rápido é usar o portal/configuração oficial do Hermes quando disponível.

## 3. Criar pasta de trabalho do aluno

```bash
mkdir -p ~/imersao-hermes ~/projetos ~/crm ~/midia
```

Copiar este kit para:

```bash
~/imersao-hermes/
```

Depois pedir ao agente:

```text
Leia ~/imersao-hermes/01_BASE_DO_AGENTE_HERMES.md e use como base operacional deste projeto. Depois leia os demais arquivos da pasta e me diga o que falta configurar.
```

## 4. Telegram

Objetivo: o aluno falar com o agente pelo Telegram.

Fluxo geral:
1. Criar bot no BotFather se necessário.
2. Guardar token com segurança.
3. Configurar o gateway/messaging do Hermes conforme documentação atual.
4. Definir chat permitido do aluno.
5. Testar mensagem: `oi`.

Regra:
- Não colar token em grupo.
- Não misturar bot de um aluno com outro.
- Cada aluno deve ter seu próprio bot ou pelo menos seu próprio chat autorizado.

## 5. Navegador visual

O agente deve ter navegador para:
- abrir Instagram;
- abrir painéis;
- fazer conferência visual;
- permitir login manual do aluno.

Regra de login:
- O aluno digita senha e 2FA manualmente.
- O agente nunca pede senha no chat.
- Se aparecer checkpoint, app approval ou bloqueio, o aluno resolve no dispositivo dele.

## 6. Composio/MCP

Objetivo: conectar ferramentas externas de forma organizada.

Possíveis integrações:
- Instagram/postagem quando disponível.
- Google Drive/Calendar.
- Slack/Discord/Notion/CRM, se o aluno usar.
- Ferramentas de social, conteúdo ou armazenamento.

Fluxo geral:
1. Criar/abrir conta Composio do aluno.
2. Conectar apps necessários.
3. Autorizar escopos mínimos.
4. Configurar MCP no Hermes.
5. Testar listagem de ferramentas.
6. Fazer uma ação pequena de teste, sem publicar nada sensível.

Regra:
- Menos permissões é melhor.
- Antes de postar/enviar/editar, o agente pede aprovação.

## 7. Modelos/API

Opções:
- Portal oficial do Hermes.
- OpenRouter para modelos baratos/gratuitos em tarefas simples.
- OpenAI/DeepSeek quando o aluno tiver API key.

Cuidados:
- Assinatura ChatGPT não é API.
- API key é segredo.
- Se acabar saldo, o agente pode parar ou dar erro.

## 8. Testes mínimos

Peça ao agente executar:

```text
Verifique se você consegue: pesquisar na web, ler e escrever arquivos, abrir navegador, responder no Telegram e listar ferramentas conectadas. Me dê um relatório curto do que está funcionando e do que falta.
```

Checklist:
- [ ] Hermes responde no terminal.
- [ ] Hermes responde no Telegram.
- [ ] Web search funciona.
- [ ] Navegador abre.
- [ ] Arquivos são criados em `~/projetos`.
- [ ] Composio/MCP aparece, se conectado.
- [ ] Agente leu `01_BASE_DO_AGENTE_HERMES.md`.

## 9. Estrutura sugerida por aluno

```text
/root/imersao-hermes/
/root/projetos/
/root/crm/leads.csv
/root/midia/
/root/relatorios/
```

## 10. Primeira ordem para o agente do aluno

```text
Minha oferta é [oferta]. Meu público é [público]. Minha região é [cidade/região]. Quero que você monte minha primeira base com 20 leads públicos, qualifique cada um e escreva mensagens personalizadas. Não envie nada ainda.
```
