# Guia mastigado: WhatsApp, Evolution, Composio, navegador e Tailscale

Este arquivo é para o Gumercindo operador/coordenador seguir com os alunos depois que o Hermes já estiver instalado na VPS e respondendo no Telegram.

## Objetivo

Cada aluno precisa sair com uma base operacional parecida com esta:

1. Hermes instalado na VPS.
2. Telegram funcionando.
3. Modelo/LLM funcionando.
4. WhatsApp conectado com segurança para atendimento/prospecção.
5. Composio/MCP conectado para ferramentas externas.
6. Navegador real disponível para login manual, Instagram, painéis e social selling.
7. Tailscale preparado para acesso seguro à VPS/navegador quando necessário.

## Decisão recomendada para WhatsApp

Para a aula, o caminho mais seguro e operacional é:

```text
WhatsApp → Evolution API → Hermes/agente → Telegram/CRM/arquivos
```

Por quê:

- Evolution permite conexão por QR Code.
- Dá para criar uma instância por aluno.
- Dá para testar status, envio e leitura por API.
- É melhor que depender de WhatsApp Web aberto em navegador para cada aluno.
- Evita que o agente precise ficar com a sessão visual aberta o tempo todo.

## Regra importante

```text
Uma conta de WhatsApp = uma instância Evolution conectada.
```

Não conectar o mesmo número em duas instâncias diferentes. Isso pode derrubar sessão, gerar `device_removed` ou deixar a conta presa em `connecting`.

## Antes de conectar WhatsApp

Perguntar para cada aluno:

1. Qual número de WhatsApp ele vai usar?
2. Esse número é pessoal ou comercial?
3. Ele aceita usar esse número para testes na aula?
4. Ele entende que automação agressiva pode gerar bloqueio?
5. O objetivo inicial é atendimento, prospecção, follow-up ou organização de leads?

Se for número pessoal, orientar:

```text
Vamos usar com cuidado, baixo volume e com autorização manual. Nada de disparo em massa.
```

## Arquitetura sugerida por aluno

Use nomes de instância padronizados:

```text
aluno-nome-whatsapp
```

Exemplos:

```text
aluno-joao-whatsapp
aluno-maria-whatsapp
aluno-paulo-whatsapp
```

Arquivos do aluno:

```text
~/imersao-hermes/
~/crm/leads.csv
~/whatsapp/logs/
~/whatsapp/templates/
~/relatorios/
```

## Passo 1: verificar se a Evolution existe

No servidor onde a Evolution está rodando, testar:

```bash
curl -s http://127.0.0.1:8085/ | head
```

ou, se a Evolution estiver em outra porta/domínio, usar o endereço real.

Também verificar as instâncias:

```bash
curl -s -H "apikey: SUA_CHAVE_EVOLUTION" \
  http://127.0.0.1:8085/instance/fetchInstances
```

Nunca mostrar a chave no telão, grupo ou print.

## Passo 2: criar instância do aluno

Modelo de comando, usando placeholders:

```bash
INSTANCE="aluno-joao-whatsapp"
EVOLUTION_URL="http://127.0.0.1:8085"
EVOLUTION_KEY="COLE_A_CHAVE_AQUI_SOMENTE_NO_TERMINAL"

curl -s -X POST "$EVOLUTION_URL/instance/create" \
  -H "Content-Type: application/json" \
  -H "apikey: $EVOLUTION_KEY" \
  -d '{
    "instanceName": "'"$INSTANCE"'",
    "qrcode": true,
    "integration": "WHATSAPP-BAILEYS"
  }'
```

Se a versão da Evolution usar payload diferente, o Gumercindo operador deve consultar a rota atual da instância já usada no servidor.

## Passo 3: abrir QR Code

Depois de criar a instância, buscar conexão/QR.

Tentar:

```bash
curl -s -H "apikey: $EVOLUTION_KEY" \
  "$EVOLUTION_URL/instance/connect/$INSTANCE"
```

Se retornar QR/base64, abrir para o aluno escanear.

O aluno faz no celular:

```text
WhatsApp → Aparelhos conectados → Conectar aparelho → escanear QR
```

## Passo 4: confirmar que conectou

Depois do QR, verificar:

```bash
curl -s -H "apikey: $EVOLUTION_KEY" \
  "$EVOLUTION_URL/instance/fetchInstances"
```

Procurar a instância do aluno e confirmar:

```text
connectionStatus: open
```

Se aparecer `close`, `connecting` ou `device_removed`, não seguir. Corrigir conexão primeiro.

## Passo 5: salvar configuração do aluno

Criar arquivo local na VPS do aluno:

```bash
mkdir -p ~/.hermes/aluno-config ~/whatsapp/logs ~/whatsapp/templates
nano ~/.hermes/aluno-config/whatsapp.env
```

Conteúdo modelo:

```bash
EVOLUTION_URL="http://ENDERECO_DA_EVOLUTION"
EVOLUTION_INSTANCE="aluno-joao-whatsapp"
EVOLUTION_API_KEY="COLE_AQUI_NO_TERMINAL_NAO_NO_CHAT"
WHATSAPP_OWNER_NUMBER="55DDDNUMERO"
```

Proteger:

```bash
chmod 600 ~/.hermes/aluno-config/whatsapp.env
```

## Passo 6: teste mínimo de envio

Antes de liberar qualquer automação, enviar uma mensagem de teste para o próprio aluno.

```bash
source ~/.hermes/aluno-config/whatsapp.env
DESTINO="55DDDNUMERO"

curl -s -X POST "$EVOLUTION_URL/message/sendText/$EVOLUTION_INSTANCE" \
  -H "Content-Type: application/json" \
  -H "apikey: $EVOLUTION_API_KEY" \
  -d '{
    "number": "'"$DESTINO"'",
    "text": "Teste do agente Hermes no WhatsApp. Se chegou, responda OK."
  }'
```

Só dizer que funcionou depois de ver:

1. API aceitou.
2. Mensagem apareceu no WhatsApp.
3. Aluno recebeu/respondeu.

## Passo 7: regra para prospecção no WhatsApp

Não liberar disparo em massa na aula.

Fluxo seguro:

1. Agente pesquisa leads públicos.
2. Agente cria mensagem personalizada.
3. Aluno aprova.
4. Agente envia uma por vez ou em lote pequeno.
5. Agente registra resposta no CRM.
6. Follow-up só se fizer sentido.

Prompt para o agente:

```text
Você pode preparar mensagens de WhatsApp, mas não envie nenhuma mensagem sem eu aprovar. Antes de enviar, mostre nome do contato, número, contexto, texto exato e motivo do contato. Depois do envio, registre no CRM.
```

## Passo 8: atendimento no WhatsApp

Para atendimento, o agente deve classificar assunto:

- preço
- agendamento
- dúvida sobre serviço
- suporte
- orçamento
- reclamação
- pedido de humano
- fora de escopo

Resposta segura:

```text
Entendi. Vou te ajudar com isso. Só para confirmar: [resumo do que a pessoa pediu].
```

Se tiver risco comercial, financeiro, jurídico, saúde ou promessa sensível, transferir para humano.

## Passo 9: Composio/MCP

Objetivo: conectar ferramentas externas ao Hermes.

Comando atual recomendado para Composio no Hermes:

```bash
hermes mcp add composio --url https://connect.composio.dev/mcp --auth oauth --connect-timeout 315
```

Fluxo:

1. Rodar comando na VPS.
2. Hermes mostra link de autorização.
3. Aluno abre link no navegador.
4. Faz login no Composio.
5. Autoriza somente apps necessários.
6. Volta para o terminal.
7. Verifica:

```bash
hermes mcp list
hermes mcp test composio
```

Depois precisa reiniciar sessão/gateway para ferramentas novas aparecerem:

```bash
hermes gateway restart
```

ou sair e abrir nova sessão `hermes`.

## Passo 10: navegador

O navegador é necessário para:

- Instagram
- login manual
- sites que bloqueiam API
- conferência visual
- painéis
- publicações manuais assistidas

Regra:

```text
O aluno faz login manual. O agente não pede senha nem código 2FA no chat.
```

Se for navegador remoto na VPS, preferir acesso via Tailscale ou desktop protegido, nunca porta pública aberta para todo mundo.

## Passo 11: Tailscale

Tailscale serve para acessar com segurança serviços internos da VPS, como navegador remoto, painel, VNC ou ferramenta local.

Instalar:

```bash
curl -fsSL https://tailscale.com/install.sh | sh
sudo tailscale up
```

O aluno abre o link de login, entra na conta e autoriza a máquina.

Ver IP da máquina:

```bash
tailscale ip -4
```

Ver status:

```bash
tailscale status
```

Regra de segurança:

```text
Não abrir navegador remoto, VNC, painel ou serviço sensível em 0.0.0.0 público sem proteção.
```

## Passo 12: prompt para o agente do aluno

Depois de tudo conectado, mandar para o Hermes do aluno:

```text
Leia os arquivos da pasta ~/imersao-hermes. Depois verifique meu ambiente: Telegram, modelo de IA, WhatsApp/Evolution, Composio/MCP, navegador e Tailscale. Não envie mensagem, não publique nada e não mexa em conta externa sem minha aprovação. Me entregue uma tabela simples com: item, status, o que está funcionando, o que falta e próximo passo.
```

## Checklist final

- [ ] Hermes responde no terminal.
- [ ] Hermes responde no Telegram.
- [ ] Modelo/LLM funciona.
- [ ] WhatsApp conectado em instância própria.
- [ ] Evolution mostra `open`.
- [ ] Mensagem de teste recebida.
- [ ] CRM criado.
- [ ] Composio/MCP conectado ou explicado como pendente.
- [ ] Navegador disponível ou plano de acesso definido.
- [ ] Tailscale instalado quando houver acesso remoto visual.
- [ ] Aluno sabe que login/senha/2FA são sempre manuais.
