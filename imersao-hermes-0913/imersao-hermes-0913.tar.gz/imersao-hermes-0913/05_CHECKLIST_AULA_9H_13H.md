# Checklist da imersão 9h às 13h

## Meta da aula
Cada aluno sair com um agente Hermes funcionando e entendendo como pedir tarefas reais.

## Antes da aula
- [ ] 4 VPS criadas ou acessos definidos.
- [ ] Domínio/subdomínio opcional definido, se houver.
- [ ] Cada aluno com Telegram ativo.
- [ ] Cada aluno com e-mail para autorizações.
- [ ] Cada aluno com Instagram que deseja operar, se for usar social selling.
- [ ] Explicar que senha nunca deve ser mandada em grupo/chat.

## 9h às 9h30 — visão geral
- [ ] Mostrar o que o Hermes faz.
- [ ] Explicar: agente não é só chatbot, ele executa tarefas.
- [ ] Explicar segurança: pedir confirmação antes de publicar/enviar em nome do aluno.
- [ ] Explicar que automação agressiva em redes pode restringir conta.

## 9h30 às 10h30 — instalação
- [ ] Rodar instalador Hermes.
- [ ] Rodar `hermes setup --portal` ou configurar provider escolhido.
- [ ] Conectar Telegram.
- [ ] Testar mensagem no Telegram.
- [ ] Criar pasta de trabalho do aluno.
- [ ] Copiar este kit para a VPS.
- [ ] Fazer o agente ler `01_BASE_DO_AGENTE_HERMES.md`.

## 10h30 às 11h15 — ferramentas
- [ ] Testar web search.
- [ ] Testar leitura/escrita de arquivo.
- [ ] Testar navegador visual.
- [ ] Conectar Composio/MCP se disponível.
- [ ] Explicar login manual no navegador.

## 11h15 às 12h — caso prático de prospecção
- [ ] Definir oferta do aluno.
- [ ] Definir ICP.
- [ ] Pedir lista de 20 leads públicos.
- [ ] Montar CRM simples.
- [ ] Criar mensagem de abordagem com opt-out e sem promessa falsa.
- [ ] Simular follow-up.

## 12h às 12h40 — social selling e conteúdo
- [ ] Abrir Instagram no navegador.
- [ ] Aluno faz login manual.
- [ ] Agente analisa perfil e concorrentes.
- [ ] Agente sugere ações leves: curtir, seguir, comentar com contexto.
- [ ] Criar roteiro de Reels ou post.
- [ ] Se houver vídeo, testar edição simples com cortes/legendas quando ferramentas estiverem disponíveis.

## 12h40 às 13h — operação diária
- [ ] Ensinar comandos de rotina.
- [ ] Criar lista de tarefas do aluno.
- [ ] Ensinar: revisar, aprovar, pausar, corrigir.
- [ ] Definir próximos passos de cada aluno.

## Entrega mínima por aluno
- [ ] Hermes funcionando na VPS.
- [ ] Telegram respondendo.
- [ ] Arquivo base lido pelo agente.
- [ ] Primeiro CRM criado.
- [ ] Primeiro plano de prospecção criado.
- [ ] Primeiro roteiro/post criado.
- [ ] Aluno sabe pedir e aprovar tarefas.
