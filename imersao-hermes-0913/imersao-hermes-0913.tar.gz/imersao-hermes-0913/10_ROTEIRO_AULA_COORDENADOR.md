# Roteiro falado da aula 9h às 13h

## Abertura
Hoje o objetivo não é só mostrar IA. É cada um sair com um operador digital próprio rodando em uma VPS, acessível pelo Telegram, capaz de pesquisar, organizar tarefas, criar conteúdo, montar base de leads e operar ferramentas com autorização.

## Explicação simples
O Hermes é um agente. Ele consegue conversar, usar ferramentas, abrir navegador, ler arquivos, criar arquivos, pesquisar na internet, organizar tarefas e aprender contexto.

A diferença para um ChatGPT normal é que ele fica instalado em um ambiente, com memória, arquivos, gateway Telegram e ferramentas.

## Segurança
Reforçar:
- senha não se manda no chat;
- token não se manda em grupo;
- login de Instagram é manual;
- postagem, curtida, comentário e mensagem só com aprovação;
- nada de spam.

## Demonstração 1 — terminal
Mostrar:

```bash
hermes
```

Perguntar algo simples.

## Demonstração 2 — Telegram
Mostrar o bot respondendo no Telegram.

## Demonstração 3 — base operacional
Mostrar o arquivo `01_BASE_DO_AGENTE_HERMES.md` e explicar que ele transforma o Hermes genérico em um agente operacional para aquele aluno.

## Demonstração 4 — prospecção
Prompt:

```text
Minha oferta é criação de sites para clínicas de estética. Meu público são clínicas no Rio de Janeiro. Monte 10 leads públicos e explique por que cada um tem fit. Não envie nada.
```

## Demonstração 5 — social selling
Explicar sem necessariamente executar volume:

```text
Abra o Instagram no navegador. Eu faço login. Depois analise seguidores de um perfil relacionado e me traga 10 perfis com fit. Não curta, siga ou comente sem eu aprovar.
```

## Fechamento
Cada aluno deve sair sabendo pedir:
- pesquisar leads;
- montar CRM;
- criar mensagem;
- aprovar envio;
- pedir conteúdo;
- pedir relatório diário;
- pausar ações.

## Frase-chave para os alunos
Não peça para o Hermes “fazer marketing”. Peça uma tarefa concreta, com contexto, limite e formato de entrega.
