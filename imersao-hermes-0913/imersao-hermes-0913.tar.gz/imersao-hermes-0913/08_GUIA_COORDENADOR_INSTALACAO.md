# Guia do coordenador - instalação Hermes na VPS

Este é o roteiro para você conduzir a instalação dos 4 alunos amanhã.

## Visão geral do fluxo

Cada aluno precisa de:

1. VPS contratada.
2. IP da VPS.
3. Usuário e senha ou chave SSH.
4. Telegram pessoal.
5. Bot criado no BotFather.
6. Hermes instalado.
7. Modelo/provider configurado.
8. Gateway Telegram configurado.
9. Kit da imersão copiado para a VPS.
10. Agente lendo o arquivo base.

## Parte 1 — contratar VPS

Oriente o aluno a contratar uma VPS Ubuntu.

Configuração mínima sugerida:
- Ubuntu 22.04 ou 24.04.
- 2 GB RAM mínimo.
- 1 vCPU mínimo.
- 20 GB disco mínimo.

Melhor para não travar:
- 4 GB RAM.
- 2 vCPU.
- 40 GB disco.

Para navegador visual, quanto mais RAM melhor. Se o aluno for editar vídeo pesado ou rodar IA local, VPS comum não basta, precisa GPU. Para Hermes, prospecção, navegador, Telegram e tarefas normais, VPS comum serve.

## Parte 2 — entrar na VPS

No terminal do aluno:

```bash
ssh root@IP_DA_VPS
```

Se pedir confirmação:

```text
yes
```

Depois digita a senha da VPS.

## Parte 3 — rodar instalador base

Na VPS, colar:

```bash
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
```

Se você quiser usar o instalador complementar deste kit, copie o arquivo `instalar_hermes_vps.sh` para a VPS e rode:

```bash
chmod +x instalar_hermes_vps.sh
./instalar_hermes_vps.sh
```

Ele instala dependências básicas, Hermes e cria pastas.

## Parte 4 — configurar Hermes

Caminho recomendado:

```bash
hermes setup --portal
```

Se não for usar portal:

```bash
hermes setup
```

ou:

```bash
hermes model
```

O importante é terminar com o Hermes respondendo no terminal.

Teste:

```bash
hermes
```

Mensagem de teste:

```text
Responda apenas: Hermes funcionando.
```

## Parte 5 — criar bot no Telegram

No Telegram do aluno:

1. Procurar `@BotFather`.
2. Enviar `/newbot`.
3. Dar um nome visível. Exemplo: `Agente João Hermes`.
4. Dar um username que termine em `bot`. Exemplo: `joao_hermes_2026_bot`.
5. Copiar o token.

Atenção:
- token é segredo;
- não mandar em grupo;
- cada aluno deve ter seu bot.

## Parte 6 — pegar Telegram user ID

No Telegram:

1. Procurar `@userinfobot` ou bot equivalente de ID.
2. Enviar `/start`.
3. Copiar o número do ID.

Esse número entra como usuário permitido.

## Parte 7 — configurar gateway Telegram

Na VPS:

```bash
hermes gateway setup
```

Escolher Telegram quando aparecer.

O assistente vai pedir:
- bot token;
- allowed users / Telegram user ID.

Depois testar no foreground:

```bash
hermes gateway
```

Abrir Telegram, entrar no bot e mandar:

```text
oi
```

Se responder, parar o foreground com `Ctrl+C`.

## Parte 8 — deixar gateway permanente

Na VPS:

```bash
hermes gateway install
hermes gateway start
hermes gateway status
```

Se precisar ver logs:

```bash
tail -f ~/.hermes/logs/gateway.log
```

ou, se instalou como serviço de usuário:

```bash
journalctl --user -u hermes-gateway -f
```

## Parte 9 — copiar kit da imersão

Criar pasta:

```bash
mkdir -p ~/imersao-hermes
```

Copiar os arquivos deste kit para essa pasta.

Se estiver com o pacote `.tar.gz`:

```bash
tar -xzf imersao-hermes-0913.tar.gz
cp -r imersao-hermes-0913/* ~/imersao-hermes/
```

## Parte 10 — fazer o agente ler a base

No Telegram ou terminal do Hermes do aluno, mandar:

```text
Leia todos os arquivos da pasta ~/imersao-hermes, começando por ~/imersao-hermes/01_BASE_DO_AGENTE_HERMES.md. Use isso como base operacional deste projeto. Depois me faça 7 perguntas para entender minha oferta, público e meta comercial.
```

## Diagnóstico rápido

### Hermes não encontrado
Rodar:

```bash
export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"
hermes --version
```

### Bot não responde
Checar:

```bash
hermes gateway status
hermes gateway
```

Problemas comuns:
- token errado;
- allowed user ID errado;
- gateway não iniciado;
- bot não recebeu `/start` do aluno.

### Ninguém pode falar com o bot
Normalmente é allowlist vazia ou ID errado. Refaça:

```bash
hermes gateway setup
```

### Como parar

```bash
hermes gateway stop
```

## Checklist final por aluno

- [ ] VPS acessada.
- [ ] Hermes instalado.
- [ ] Hermes responde no terminal.
- [ ] Bot criado no BotFather.
- [ ] Telegram user ID anotado.
- [ ] `hermes gateway setup` concluído.
- [ ] Bot responde no Telegram.
- [ ] Gateway instalado/iniciado.
- [ ] Kit copiado.
- [ ] Agente leu arquivo base.
- [ ] Primeiro plano de prospecção criado.
