# Cartão do aluno

Preencha para cada aluno durante a instalação.

```text
Nome do aluno:
Negócio/oferta:
VPS IP:
Usuário VPS:
Telegram @:
Telegram user ID:
Nome do bot:
Username do bot:
Provider/modelo usado:
Composio conectado? sim/não
Instagram para operar:
Pasta do kit na VPS:
Status final:
Próxima ação:
```

## Checklist individual

- [ ] Entrou na VPS.
- [ ] Instalou Hermes.
- [ ] Configurou modelo.
- [ ] Hermes respondeu no terminal.
- [ ] Criou bot.
- [ ] Pegou Telegram user ID.
- [ ] Configurou gateway.
- [ ] Bot respondeu no Telegram.
- [ ] Gateway ficou permanente.
- [ ] Kit copiado.
- [ ] Agente leu base.
- [ ] Primeira tarefa comercial criada.
