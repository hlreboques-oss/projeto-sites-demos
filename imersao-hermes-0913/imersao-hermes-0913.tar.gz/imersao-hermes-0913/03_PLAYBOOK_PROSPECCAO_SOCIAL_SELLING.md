# Playbook de prospecção e social selling com Hermes

## Objetivo
Usar o Hermes para encontrar oportunidades, alimentar base própria, criar mensagens e apoiar relacionamento comercial sem virar spam.

## Parte 1 — Definir oferta
Antes de procurar leads, responda:

- O que eu vendo?
- Para quem eu vendo?
- Qual dor eu resolvo?
- Qual resultado prometo com segurança?
- Qual ticket?
- Qual região?
- Que tipo de cliente eu não quero?

Prompt:

```text
Me entreviste para definir minha oferta, ICP e critérios de qualificação. Depois transforme isso em uma regra de busca de leads.
```

## Parte 2 — Buscar leads públicos
Fontes:
- Google.
- Instagram público.
- Google Maps.
- Sites de associações.
- Diretórios públicos.
- Páginas de concorrentes.
- Comentários públicos em posts relacionados.

Prompt:

```text
Pesquise 30 leads públicos para minha oferta. Para cada lead, traga nome, link, cidade, contato público se existir, motivo do encaixe e nota de prioridade de 1 a 5. Não envie mensagem ainda.
```

## Parte 3 — CRM simples
Criar CSV com:

```csv
data,nome,nicho,cidade,link,contato_publico,origem,dor_provavel,oferta_sugerida,status,proxima_acao,observacoes
```

Status:
- pesquisado
- qualificado
- abordagem_pronta
- abordado
- respondeu
- interessado
- reuniao
- proposta
- ganho
- perdido
- nao_contatar

Prompt:

```text
Crie um CRM em CSV para esses leads e mantenha atualizado a cada ação. Antes de qualquer envio, me mostre a mensagem.
```

## Parte 4 — Mensagem de abordagem
Boa abordagem:
- curta;
- contextual;
- sem promessa absurda;
- com pergunta simples;
- respeitosa;
- sem parecer automação.

Modelo:

```text
Oi, [nome]. Vi que vocês trabalham com [contexto real].
Eu ajudo [tipo de negócio] a [resultado] usando [mecanismo].
Faz sentido eu te mandar uma ideia rápida aplicada ao seu caso?
```

Não usar:
- textão;
- mentira;
- pressão;
- “garanto resultado”; 
- 10 mensagens seguidas;
- comentário genérico igual em todo perfil.

## Parte 5 — Follow-up
Regra:
- Só fazer follow-up se a pessoa não pediu para parar.
- Não insistir demais.
- Mudar ângulo, não repetir a mesma mensagem.

Exemplo:

```text
Oi, [nome]. Passando só para não deixar morrer: posso te mandar um exemplo prático de como isso ficaria no seu negócio?
```

## Parte 6 — Social selling no Instagram

### Fontes de público
- Seguidores de concorrentes.
- Quem comentou em posts recentes.
- Perfis que seguem hashtags do nicho.
- Perfis localizados na cidade alvo.
- Pessoas que interagem com criadores do segmento.

### Ações possíveis
Com autorização:
- visitar perfil;
- curtir até 3 posts relevantes;
- visualizar/curtir story quando fizer sentido;
- seguir perfil;
- comentar algo específico e humano;
- salvar lead no CRM.

### Limites sugeridos no começo
- Começar com 5 a 10 perfis por bloco.
- Pausar entre blocos.
- Não repetir comentários.
- Se aparecer limite/checkpoint, parar.

Prompt:

```text
Abra o Instagram. Eu vou fazer login. Depois analise o perfil @perfil_relacionado e me traga 10 perfis com fit para minha oferta. Para cada um, diga por que faz sentido e que ação leve você recomenda. Não curta, siga ou comente sem eu aprovar.
```

## Parte 7 — Disparo de hora em hora com cautela
Se o aluno quiser rotina recorrente, não fazer volume alto.

Rotina segura:
1. A cada hora, pesquisar poucos leads.
2. Atualizar CRM.
3. Preparar mensagens.
4. Pedir aprovação ou enviar só quando houver autorização explícita.
5. Parar se houver bloqueio, reclamação ou sinal de restrição.

Prompt:

```text
Monte uma rotina de prospecção leve para rodar de hora em hora: pesquisar 5 leads, qualificar, salvar no CRM e me pedir aprovação antes de qualquer envio.
```

## Parte 8 — Métricas
Acompanhar:
- leads pesquisados;
- leads qualificados;
- abordagens aprovadas;
- respostas;
- interessados;
- reuniões;
- vendas;
- bloqueios/opt-out;
- melhor fonte de lead.

Prompt de relatório:

```text
Faça o relatório de hoje: quantos leads pesquisou, quantos tinham fit, quantos foram abordados, quantos responderam, quem está quente e qual próxima ação.
```

## Parte 9 — O que fazer quando alguém responde
Classificar:
- negativo claro;
- dúvida;
- interesse vago;
- interesse real;
- pedido de preço;
- reunião;
- cliente quente.

Regra:
- Interesse vago recebe pergunta de qualificação.
- Interesse real recebe proposta/próximo passo.
- Negativo claro vai para `nao_contatar`.

Exemplo:

```text
Legal. Para eu te mandar algo útil, hoje sua maior dificuldade é conseguir mais clientes, responder melhor quem chama, ou organizar follow-up?
```

## Parte 10 — Segurança e reputação
- Não burlar Meta/Instagram.
- Não comprar lista fria sem critério.
- Não usar conta nova com alto volume.
- Não mandar mensagem para quem pediu para parar.
- Não deixar agente publicar ou enviar sem revisão no começo.
