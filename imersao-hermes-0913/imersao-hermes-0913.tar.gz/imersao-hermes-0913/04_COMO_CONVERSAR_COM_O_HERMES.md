# Como conversar com o Hermes

## Regra principal
Fale com o Hermes como se estivesse falando com um operador inteligente. Diga objetivo, contexto, limite e como quer validar.

## Fórmula simples de pedido

```text
Objetivo: quero conseguir clientes para [oferta].
Contexto: meu público é [público], na região [cidade], ticket [valor].
Limites: não envie nada sem eu aprovar. Não use mensagens agressivas.
Entrega: me traga uma lista de leads com nome, link, motivo e mensagem sugerida.
```

## Pedidos bons

### Pesquisa de mercado
```text
Pesquise 30 negócios em [cidade] que podem comprar [minha oferta]. Monte uma tabela com nome, Instagram/site, WhatsApp se for público, motivo do encaixe e prioridade.
```

### Prospecção sem envio automático
```text
Analise esses leads e escreva uma primeira mensagem personalizada para cada um. Não envie ainda. Quero aprovar antes.
```

### Social selling no Instagram
```text
Abra o Instagram no navegador. Eu vou fazer login manualmente. Depois analise o perfil @exemplo e me diga seguidores com perfil parecido com meu cliente ideal. Antes de curtir, seguir ou comentar, me peça aprovação.
```

### Organização de tarefas
```text
Transforme tudo que preciso fazer hoje em uma lista de tarefas. Execute uma por vez e me avise antes de qualquer ação externa.
```

### Correção de rota
```text
Pausa. Você está indo rápido demais. Faça só a etapa 1 e espere minha aprovação.
```

### Conteúdo
```text
Crie 5 roteiros de Reels para vender [oferta], com gancho forte, desenvolvimento curto e CTA. Não use linguagem robótica.
```

### Edição de vídeo
```text
Tenho este vídeo bruto. Corte pausas, sugira legenda curta, crie título e me entregue uma versão para Reels. Se precisar de ferramenta externa, me explique antes.
```

## Como aprovar com segurança
Use frases claras:

- `Aprovado, pode enviar apenas para esses 5.`
- `Não envie. Só salve no CRM.`
- `Pode postar agora no perfil X.`
- `Pare os disparos.`
- `Refaça com tom mais humano.`

## O que nunca fazer
- Não mandar senha no chat.
- Não colar token/API key em grupo.
- Não pedir para o agente fazer spam.
- Não pedir para burlar bloqueio do Instagram/Meta.
- Não deixar publicar/enviar sem revisar quando envolver reputação.

## Rotina diária sugerida

```text
Bom dia. Revise minha lista de tarefas, meus leads e minhas pendências. Me diga as 3 ações que mais podem gerar dinheiro hoje. Execute a primeira sem enviar nada para fora antes da minha aprovação.
```

No fim do dia:

```text
Faça um relatório do que foi feito, o que gerou resposta, o que está pendente e quais são as próximas ações para amanhã.
```
