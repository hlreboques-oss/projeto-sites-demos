# Guia LLM para a imersão: ChatGPT/Codex OAuth, OpenRouter grátis e OpenAI API

## Ideia

O Hermes precisa de um modelo de IA configurado. Para a aula, explique assim:

1. **ChatGPT/Codex com assinatura**: não é API key. É login por OAuth/device code dentro do Hermes.
2. **OpenRouter com modelo gratuito**: opção grátis/barata para quem não tem crédito.
3. **OpenAI API**: opção separada, paga por uso, para quem quer usar chave da plataforma OpenAI.

## Opção 1 — ChatGPT/Codex com assinatura, via OAuth

Essa é a opção para quem já paga ChatGPT/Codex e quer usar no Hermes sem chave de API.

### Aviso importante

> Assinatura ChatGPT não é OpenAI API. No Hermes, o caminho da assinatura é **OpenAI Codex / ChatGPT Subscription via OAuth ou device code**.

### Passo humano

1. No terminal da VPS, rodar:

```bash
hermes model
```

2. Escolher a opção parecida com:

```text
ChatGPT or Codex Subscription
OpenAI Codex
```

3. O Hermes vai mostrar um link e/ou código.
4. O aluno abre o link no navegador.
5. Faz login na conta ChatGPT/Codex.
6. Autoriza.
7. Volta para o terminal e confirma se o Hermes aceitou.

### Se precisar forçar login pelo navegador

```bash
hermes auth add openai-codex --browser
```

Use isso se o fluxo padrão por código não funcionar bem.

## Opção 2 — OpenRouter grátis/barato

Link da chave:

https://openrouter.ai/keys

Link dos modelos grátis:

https://openrouter.ai/collections/free-models

Modelo gratuito sugerido para testar:

```text
nvidia/nemotron-3-ultra-550b-a55b:free
```

Link direto:

https://openrouter.ai/nvidia/nemotron-3-ultra-550b-a55b:free

### Passo humano

1. Criar conta ou fazer login no OpenRouter.
2. Abrir API Keys.
3. Criar chave.
4. Copiar a chave.
5. No Hermes, rodar:

```bash
hermes model
```

6. Escolher OpenRouter.
7. Colar a chave.
8. Escolher modelo gratuito quando solicitado.

### Observação

OpenRouter pode ter modelo grátis, mas pode ter limite, fila, instabilidade ou mudança de disponibilidade. Para operação séria, é melhor colocar crédito.

## Opção 3 — OpenAI API, paga por uso

Link:

https://platform.openai.com/api-keys

Essa opção é diferente da assinatura ChatGPT. Aqui o aluno precisa criar uma chave de API e normalmente adicionar billing/crédito.

### Passo humano

1. Entrar no link.
2. Fazer login.
3. Criar API key.
4. Copiar a chave uma única vez.
5. Adicionar billing/crédito se a plataforma pedir.

No Hermes:

```bash
hermes model
```

Escolher OpenAI/API e colar a chave quando o assistente pedir.

## Frase correta para explicar na aula

```text
Se você tem assinatura ChatGPT/Codex, não vamos usar API key. Vamos conectar pelo Hermes com login OAuth/device code na opção ChatGPT or Codex Subscription. Se você não tiver assinatura ou crédito, vamos usar OpenRouter com modelo gratuito, como Nemotron. OpenAI API é uma terceira opção, separada, paga por uso e diferente da assinatura ChatGPT.
```
