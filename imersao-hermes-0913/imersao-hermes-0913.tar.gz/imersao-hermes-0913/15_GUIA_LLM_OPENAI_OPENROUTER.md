# Guia LLM para a imersão: OpenAI pago e OpenRouter grátis

## Ideia
O Hermes precisa de um modelo de IA configurado. Para a aula, use duas rotas:

1. **OpenAI API** para quem consegue colocar crédito.
2. **OpenRouter com modelo gratuito** para quem não tem recurso no momento.

## Opção 1 — OpenAI API

Link:

https://platform.openai.com/api-keys

Passo humano:

1. Entrar no link.
2. Fazer login.
3. Criar API key.
4. Copiar a chave uma única vez.
5. Adicionar billing/crédito se a plataforma pedir.

Aviso importante:

> Assinatura ChatGPT não é API. A pessoa pode pagar ChatGPT e ainda assim não ter crédito para API.

No Hermes:

```bash
hermes model
```

Escolher OpenAI e colar a chave quando o assistente pedir.

## Opção 2 — OpenRouter grátis/barato

Link da chave:

https://openrouter.ai/keys

Link dos modelos grátis:

https://openrouter.ai/collections/free-models

Modelo gratuito sugerido para testar:

```text
nvidia/nemotron-3-ultra-550b-a55b:free
```

Link direto:

https://openrouter.ai/nvidia/nemotron-3-ultra-550b-a55b:free

Passo humano:

1. Criar conta ou fazer login no OpenRouter.
2. Abrir API Keys.
3. Criar chave.
4. Copiar a chave.
5. No Hermes, rodar:

```bash
hermes model
```

6. Escolher OpenRouter.
7. Colar a chave.
8. Escolher modelo gratuito quando solicitado.

## Observações sobre modelos grátis

- Podem ter limite.
- Podem ficar lentos.
- Podem falhar em horários de pico.
- Para aula e testes iniciais, servem.
- Para operação séria, é melhor ter crédito em OpenRouter/OpenAI/Nous Portal.

## Frase para explicar na aula

```text
Quem tiver condição coloca OpenAI API ou outro provider pago. Quem não tiver, começa com OpenRouter e modelo gratuito, como Nemotron. Não é o ideal para produção pesada, mas permite sair da aula com o agente funcionando.
```
