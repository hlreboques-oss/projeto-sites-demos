# Passo a passo visual — onde pegar cada informação

Use este roteiro na aula para mostrar exatamente onde o aluno clica e qual informação ele precisa copiar.

Página digital principal:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/

## Etapa 1 — Contratar ou abrir VPS na Hostinger

Link:

https://www.hostinger.com.br/vps-hosting

O humano faz:

1. Abre o link.
2. Escolhe um plano VPS KVM.
3. Finaliza contratação.
4. Depois abre o painel da Hostinger.

Imagem para mostrar:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/assets/01_hostinger_pagina_vps_anotada.jpg

O que explicar:

> Aqui é só para contratar ou acessar a VPS. Depois da contratação, o que importa é entrar no hPanel e achar a VPS criada.

## Etapa 2 — Abrir hPanel e clicar em VPS → Gerenciar

O humano faz:

1. Entra na conta da Hostinger.
2. Vai no menu VPS.
3. Encontra o servidor criado.
4. Clica em Gerenciar.

Imagem para mostrar:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/assets/02_hpanel_vps_gerenciar_modelo.jpg

O que explicar:

> Essa é a tela onde você entra no servidor. Não precisa entender tudo, só achar VPS e clicar em Gerenciar.

## Etapa 3 — Pegar IP, usuário SSH e porta

O humano faz:

1. Dentro da VPS, abre a visão geral.
2. Procura Detalhes da VPS ou Acesso SSH.
3. Copia:
   - IP da VPS
   - usuário SSH, normalmente `root`
   - porta SSH, normalmente `22`

Imagem para mostrar:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/assets/03_hpanel_ssh_dados_modelo.jpg

O que explicar:

> Esses três dados vão para o instalador assistido. Com eles, a página monta o comando de acesso SSH automaticamente.

Exemplo:

```bash
ssh root@123.45.67.89
```

## Etapa 4 — Opção mais fácil: Web Console

O humano faz:

1. Dentro da VPS, clica em Web Console ou Terminal.
2. A Hostinger abre um terminal dentro do navegador.
3. O aluno cola o comando de instalação.

Imagem para mostrar:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/assets/04_hpanel_web_console_modelo.jpg

O que explicar:

> Para aluno leigo, esse é o melhor caminho. Ele não precisa instalar terminal, PuTTY ou configurar SSH no computador. Abre o terminal direto no navegador da Hostinger.

Comando para colar:

```bash
curl -fsSL https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/install.sh | bash
```

## Etapa 5 — Criar bot no Telegram

Link:

https://t.me/BotFather

O humano faz:

1. Abre o BotFather.
2. Envia `/newbot`.
3. Escolhe nome do bot.
4. Escolhe username terminando em `bot`.
5. Copia o token.

Imagem para mostrar:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/assets/05_telegram_botfather_modelo.jpg

O que explicar:

> O token é como uma senha do bot. Não manda em grupo, não tira print mostrando token e não cola em lugar público.

## Etapa 6 — Pegar Telegram user ID

Link:

https://t.me/userinfobot

O humano faz:

1. Abre o userinfobot.
2. Envia `/start`.
3. Copia o número do ID.

O que explicar:

> Esse ID é para o Hermes saber quem pode falar com o bot. Sem allowed user correto, o bot pode não responder.

## Etapa 7 — Preencher o instalador assistido

Link:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/#instalador

O humano faz:

1. Cola o IP da VPS.
2. Confere usuário `root`.
3. Confere porta `22`.
4. Coloca nome do aluno.
5. Coloca Telegram user ID.
6. Guarda o token para usar no `hermes gateway setup`.
7. Clica em Gerar comandos.

Imagem para mostrar:

https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/assets/06_instalador_assistido_modelo.jpg

O que explicar:

> Essa página não instala sozinha dentro da VPS. Ela gera o comando certo para o aluno copiar e colar.

## Etapa 8 — Máquina instala Hermes

A máquina faz:

1. Instala dependências.
2. Instala Hermes.
3. Cria pastas.
4. Baixa o kit da imersão.

Comando:

```bash
curl -fsSL https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/install.sh | bash
```

## Etapa 9 — Configurar modelo de IA

### Opção paga: OpenAI API

Link:

https://platform.openai.com/api-keys

Atenção:

> ChatGPT assinatura não é API. Precisa de crédito/billing no Platform.

Comando:

```bash
hermes model
```

### Opção gratuita/barata: OpenRouter + Nemotron

Links:

https://openrouter.ai/keys

https://openrouter.ai/nvidia/nemotron-3-ultra-550b-a55b:free

Modelo sugerido:

```text
nvidia/nemotron-3-ultra-550b-a55b:free
```

Comando:

```bash
hermes model
```

## Etapa 10 — Conectar Telegram no Hermes

A máquina/humano fazem juntos:

```bash
hermes gateway setup
```

O humano informa:

- token do BotFather
- Telegram user ID

Depois testa:

```bash
hermes gateway
```

Se respondeu no Telegram, deixa permanente:

```bash
hermes gateway install
hermes gateway start
hermes gateway status
```

## Frase para conduzir a aula

```text
Tudo que é clique, login, compra e token é humano. Tudo que é instalar, criar pasta, baixar kit e rodar serviço é máquina. A página está aqui para juntar os dois sem o aluno precisar decorar comando.
```
