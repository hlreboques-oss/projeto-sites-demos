#!/usr/bin/env bash
set -euo pipefail

printf '\n=== Instalador Hermes VPS - Imersao 9h-13h ===\n\n'

if [ "$(id -u)" -eq 0 ]; then
  HOME_DIR="/root"
else
  HOME_DIR="$HOME"
fi

printf 'Usuario: %s\n' "$(whoami)"
printf 'Home: %s\n' "$HOME_DIR"
printf 'Sistema: '
uname -a
printf '\n'

printf '1/6 Atualizando pacotes basicos...\n'
if command -v apt-get >/dev/null 2>&1; then
  sudo apt-get update -y
  sudo apt-get install -y curl git ca-certificates python3 python3-pip ffmpeg tmux unzip nano
else
  printf 'apt-get nao encontrado. Instale curl/git/python3/ffmpeg manualmente se necessario.\n'
fi

printf '\n2/6 Instalando Hermes Agent...\n'
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash

# garantir PATH comum
export PATH="$HOME_DIR/.local/bin:$HOME_DIR/.cargo/bin:$PATH"

printf '\n3/6 Verificando comando hermes...\n'
if ! command -v hermes >/dev/null 2>&1; then
  printf 'Nao encontrei hermes no PATH atual. Tente fechar/abrir o terminal ou rode:\n'
  printf 'export PATH="$HOME/.local/bin:$HOME/.cargo/bin:$PATH"\n'
  exit 1
fi
hermes --version || true

printf '\n4/6 Criando pastas do aluno...\n'
mkdir -p "$HOME_DIR/imersao-hermes" "$HOME_DIR/projetos" "$HOME_DIR/crm" "$HOME_DIR/midia" "$HOME_DIR/relatorios"

printf '\n5/6 Criando README inicial local...\n'
cat > "$HOME_DIR/imersao-hermes/LEIA_PRIMEIRO.txt" <<'TXT'
Instalacao base concluida.

Proximos passos manuais:
1. Rode: hermes setup --portal
   ou rode: hermes setup
2. Teste no terminal: hermes
3. Configure Telegram: hermes gateway setup
4. Escolha Telegram no assistente.
5. Cole o token do BotFather quando o assistente pedir.
6. Informe seu Telegram user ID quando pedir allowed users.
7. Teste o gateway no foreground: hermes gateway
8. Se funcionar, instale como servico: hermes gateway install
9. Inicie/valide: hermes gateway start && hermes gateway status

Depois copie os arquivos do kit para esta pasta e mande o Hermes ler:
Leia ~/imersao-hermes/01_BASE_DO_AGENTE_HERMES.md e use como base operacional.
TXT

printf '\n6/6 Instalacao base finalizada.\n\n'
printf 'Agora execute uma destas opcoes:\n'
printf 'A) Configuracao mais facil com portal:\n'
printf '   hermes setup --portal\n\n'
printf 'B) Configuracao completa/manual:\n'
printf '   hermes setup\n\n'
printf 'Depois Telegram:\n'
printf '   hermes gateway setup\n'
printf '   hermes gateway\n\n'
printf 'Se o teste funcionar, deixe permanente:\n'
printf '   hermes gateway install\n'
printf '   hermes gateway start\n'
printf '   hermes gateway status\n\n'
