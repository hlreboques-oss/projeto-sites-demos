# Página digital

Também foi criada uma página HTML em:

`/root/projeto-sites-demos/imersao-hermes-0913/index.html`

Ela serve como guia visual para a aula.

Depois do push, o link será:

`https://hlreboques-oss.github.io/projeto-sites-demos/imersao-hermes-0913/`

Use esse link para os alunos acompanharem os passos principais sem precisar abrir todos os arquivos markdown.
