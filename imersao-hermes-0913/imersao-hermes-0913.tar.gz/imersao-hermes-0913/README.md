# Imersão Hermes 9h às 13h

Kit para instalar e configurar agentes Hermes individuais para os participantes.

## Objetivo da imersão
Cada participante sair com um agente Hermes próprio rodando em VPS, falando pelo Telegram, com navegador remoto para operações visuais e preparação para conectar Composio/MCP, redes sociais, prospecção, edição de vídeo e execução de tarefas.

## Arquivos deste kit

1. `01_BASE_DO_AGENTE_HERMES.md`
   - Arquivo principal para o agente do aluno ler.
   - Define identidade, limites, modo de operação, prospecção, social selling, navegador, edição de vídeo e rotinas.

2. `02_INSTALACAO_VPS_TELEGRAM_COMPOSIO.md`
   - Passo a passo de instalação em VPS.
   - Inclui Hermes, Telegram, Composio/MCP, navegador e validação.

3. `03_PLAYBOOK_PROSPECCAO_SOCIAL_SELLING.md`
   - Método de prospecção, pesquisa pública, base própria, CRM simples e Instagram/social selling com limites.

4. `04_COMO_CONVERSAR_COM_O_HERMES.md`
   - Roteiro para ensinar o aluno a pedir tarefas, aprovar ações, corrigir o agente e limpar pendências.

5. `05_CHECKLIST_AULA_9H_13H.md`
   - Cronograma da imersão e checklist de entrega.

6. `.env.example`
   - Modelo de variáveis que podem existir por aluno. Não colocar senhas reais nele.

## Como usar amanhã

Para cada aluno:

1. Instalar Hermes na VPS.
2. Conectar Telegram.
3. Colocar os arquivos deste kit em uma pasta da VPS do aluno.
4. Pedir ao agente:

```text
Leia o arquivo /caminho/01_BASE_DO_AGENTE_HERMES.md e use como base operacional deste projeto. Depois leia os demais arquivos da pasta e me diga o que falta configurar.
```

5. Fazer o agente validar:
   - Telegram responde.
   - Navegador abre.
   - Web search funciona.
   - Arquivos podem ser lidos/escritos.
   - Composio/MCP aparece quando conectado.

## Regra de ouro
O agente não deve fazer spam, não deve burlar limites de plataforma e não deve pedir senha no chat. Login sensível é sempre feito pelo aluno manualmente no navegador ou via fluxo seguro da ferramenta.
