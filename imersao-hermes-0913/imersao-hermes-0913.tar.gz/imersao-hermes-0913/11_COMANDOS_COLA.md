# Cola de comandos

## Instalar Hermes

```bash
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
```

## Configurar modelo/portal

```bash
hermes setup --portal
```

ou:

```bash
hermes setup
```

## Abrir Hermes no terminal

```bash
hermes
```

## Configurar Telegram

```bash
hermes gateway setup
```

## Testar gateway no terminal

```bash
hermes gateway
```

## Instalar gateway como serviço

```bash
hermes gateway install
```

## Iniciar/parar/status

```bash
hermes gateway start
hermes gateway stop
hermes gateway status
```

## Ver logs

```bash
tail -f ~/.hermes/logs/gateway.log
```

ou:

```bash
journalctl --user -u hermes-gateway -f
```

## Criar pastas

```bash
mkdir -p ~/imersao-hermes ~/projetos ~/crm ~/midia ~/relatorios
```

## Fazer agente ler kit

```text
Leia todos os arquivos da pasta ~/imersao-hermes, começando por ~/imersao-hermes/01_BASE_DO_AGENTE_HERMES.md. Use isso como base operacional deste projeto.
```
