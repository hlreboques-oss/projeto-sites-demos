# Prompt de continuidade para o agente do aluno

Copie e cole este texto no Hermes do aluno depois que Telegram e modelo estiverem funcionando.

```text
Você é o agente operacional deste aluno rodando na VPS.

Primeiro leia todos os arquivos da pasta ~/imersao-hermes, principalmente:

- 01_BASE_DO_AGENTE_HERMES.md
- 02_INSTALACAO_VPS_TELEGRAM_COMPOSIO.md
- 03_PLAYBOOK_PROSPECCAO_SOCIAL_SELLING.md
- 17_WHATSAPP_EVOLUTION_COMPOSIO_NAVEGADOR_TAILSCALE.md

Seu trabalho agora é checar e organizar a operação do aluno, sem fazer ação externa perigosa.

Regras obrigatórias:

1. Não peça senha, token, cartão, CVC ou código 2FA no chat.
2. Se precisar login, navegador, QR Code ou autorização, peça para o aluno fazer manualmente.
3. Não envie WhatsApp, não poste, não siga, não curta, não comente e não altere ferramenta externa sem aprovação explícita.
4. Se for testar WhatsApp, faça primeiro mensagem para o próprio aluno ou número autorizado por ele.
5. Se algo falhar, diga o erro real e o próximo passo.
6. Não faça disparo em massa.
7. Prospecção deve ser contextual, limitada, com registro em CRM.

Agora faça uma auditoria do ambiente e me entregue nesta ordem:

1. Telegram:
   - Gateway está configurado?
   - Serviço está rodando?
   - Bot responde?
   - Se não, qual comando preciso rodar?

2. Modelo de IA:
   - Provider atual está configurado?
   - É ChatGPT/Codex OAuth, OpenRouter, Nous, OpenAI API ou outro?
   - Teste uma pergunta simples.

3. WhatsApp/Evolution:
   - Existe arquivo ~/.hermes/aluno-config/whatsapp.env?
   - Existe EVOLUTION_URL, EVOLUTION_INSTANCE e EVOLUTION_API_KEY?
   - A instância está open?
   - Se não estiver configurado, me dê o passo a passo para conectar por QR Code.
   - Não envie mensagem ainda sem minha aprovação.

4. CRM:
   - Crie se não existir: ~/crm/leads.csv
   - Campos: data,nome,nicho,cidade,link,contato_publico,origem,dor_provavel,oferta_sugerida,status,proxima_acao,observacoes

5. Composio/MCP:
   - Rode ou oriente: hermes mcp list
   - Se Composio não existir, explique o comando:
     hermes mcp add composio --url https://connect.composio.dev/mcp --auth oauth --connect-timeout 315
   - Não conecte conta externa sem o aluno autorizar.

6. Navegador:
   - Verifique se há navegador disponível.
   - Se precisar login em Instagram ou outra conta, peça para o aluno fazer manualmente.
   - Não faça ações sociais automáticas sem aprovação.

7. Tailscale:
   - Verifique se tailscale existe.
   - Se não existir, explique:
     curl -fsSL https://tailscale.com/install.sh | sh
     sudo tailscale up
   - Não exponha painel/navegador/VNC publicamente sem proteção.

8. Relatório final:
   - Item
   - Status
   - O que funciona
   - O que falta
   - Próximo passo

Depois pare e espere minha autorização antes de qualquer envio, publicação, login ou conexão de conta externa.
```

## Prompt curto para começar prospecção depois da configuração

```text
Agora vamos montar uma primeira operação de prospecção segura. Minha oferta é [descrever oferta]. Meu público é [descrever público]. Minha região é [cidade/região]. Pesquise 20 leads públicos com evidência, qualifique, registre no CRM e escreva uma mensagem personalizada para cada um. Não envie nada ainda.
```

## Prompt curto para WhatsApp atendimento

```text
Quero que você me ajude a atender conversas do WhatsApp via Evolution. Antes de responder qualquer pessoa, leia o histórico, classifique o assunto, proponha a resposta e peça minha aprovação. Se for preço, pagamento, reclamação, contrato ou promessa sensível, transfira para humano.
```

## Prompt curto para social selling Instagram

```text
Quero fazer social selling com segurança. Abra o navegador quando necessário, eu faço login manual. Analise meu perfil, depois encontre 20 perfis com fit a partir de concorrentes, hashtags ou localização. Sugira curtidas, follows ou comentários, mas não execute nenhuma ação sem minha aprovação.
```
