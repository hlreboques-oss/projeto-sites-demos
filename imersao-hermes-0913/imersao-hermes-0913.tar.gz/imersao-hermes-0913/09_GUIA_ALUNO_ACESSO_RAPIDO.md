# Guia rápido do aluno

## O que você vai fazer
Você vai instalar seu próprio agente Hermes em uma VPS e falar com ele pelo Telegram.

## Você vai precisar
- VPS Ubuntu contratada.
- IP da VPS.
- Senha ou chave de acesso.
- Telegram.
- Bot criado no BotFather.

## 1. Entrar na VPS

No terminal:

```bash
ssh root@IP_DA_SUA_VPS
```

Troque `IP_DA_SUA_VPS` pelo IP real.

## 2. Instalar Hermes

Cole na VPS:

```bash
curl -fsSL https://hermes-agent.nousresearch.com/install.sh | bash
```

Depois rode:

```bash
hermes setup --portal
```

Se o professor orientar outro provider, siga o comando indicado por ele.

## 3. Testar Hermes no terminal

```bash
hermes
```

Digite:

```text
Responda apenas: funcionando.
```

## 4. Criar bot no Telegram

No Telegram:

1. Abra `@BotFather`.
2. Envie `/newbot`.
3. Escolha nome do bot.
4. Escolha username terminando em `bot`.
5. Copie o token com cuidado.

Não envie o token em grupo.

## 5. Pegar seu Telegram ID

No Telegram:

1. Abra `@userinfobot`.
2. Envie `/start`.
3. Copie seu ID numérico.

## 6. Configurar Telegram no Hermes

Na VPS:

```bash
hermes gateway setup
```

Escolha Telegram.

Cole:
- token do BotFather;
- seu Telegram user ID.

## 7. Testar bot

Na VPS:

```bash
hermes gateway
```

No Telegram, abra seu bot e mande:

```text
oi
```

Se responder, funcionou.

Depois aperte `Ctrl+C` na VPS para sair do teste.

## 8. Deixar ligado sempre

Na VPS:

```bash
hermes gateway install
hermes gateway start
hermes gateway status
```

## 9. Fazer o agente ler a base da imersão

Quando o professor liberar os arquivos do kit, peça ao agente:

```text
Leia todos os arquivos da pasta ~/imersao-hermes, começando por ~/imersao-hermes/01_BASE_DO_AGENTE_HERMES.md. Use isso como base operacional.
```

## 10. Primeiro pedido ao agente

```text
Minha oferta é [descreva]. Meu público é [descreva]. Minha cidade/região é [descreva]. Quero clientes. Monte uma lista de 20 leads públicos, qualifique e escreva mensagens. Não envie nada sem minha aprovação.
```

## Regras de segurança
- Não mande senha no chat.
- Não mande token/API key em grupo.
- Login em Instagram ou outras contas deve ser feito por você manualmente.
- O agente deve pedir autorização antes de postar, enviar mensagem, curtir, seguir ou comentar.
