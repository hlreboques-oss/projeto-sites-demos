# Modelo de relatório diário do agente

```text
Relatório do dia

1. O que foi feito
- [ação 1]
- [ação 2]
- [ação 3]

2. Prospecção
- Leads pesquisados:
- Leads qualificados:
- Mensagens preparadas:
- Mensagens enviadas com autorização:
- Respostas recebidas:
- Leads quentes:

3. Social selling
- Perfis analisados:
- Ações feitas com autorização:
- Comentários/curtidas/seguimentos:
- Sinais de limite ou bloqueio:

4. Conteúdo
- Ideias criadas:
- Roteiros prontos:
- Posts/Reels publicados:
- Pendências de aprovação:

5. Problemas
- Erro:
- Impacto:
- Sugestão de correção:

6. Próximas ações recomendadas
- Prioridade 1:
- Prioridade 2:
- Prioridade 3:
```
